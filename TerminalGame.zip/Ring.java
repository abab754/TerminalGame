public class Ring extends Accessory{
}
