import java.util.*;
public class Character {
    int damage;
    int health;
    private boolean defends;






}
