import java.util.*;
public class Fountain extends Room{

}
