public class BRoom extends Room{
    Wizard wizard;

    public BRoom(){
        wizard = new Wizard();
    }
}
