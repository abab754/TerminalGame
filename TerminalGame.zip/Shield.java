public class Shield extends Accessory{

}
