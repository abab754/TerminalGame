public class Potion extends Accessory{
}
