public class SRoom extends Room {
    public String welcomeMessage(){
        return "Hello! Welcome to the Starting room. Please type in a name for our hero.";
    }
}
