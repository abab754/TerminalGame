public class Key extends Accessory{
}
