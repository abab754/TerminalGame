public class Wizard extends Character{
    private int health, damage;

    public Wizard(){

    }

    public int getDamage(){
        return this.damage;
    }

    public int getHealth(){
        return this.health;
    }

    public void setHealth(int health){

    }

    public void setDamage(int damage){

    }
}
