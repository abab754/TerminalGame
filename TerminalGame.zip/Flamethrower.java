public class Flamethrower extends Weapon{
}
