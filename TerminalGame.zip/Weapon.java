public class Weapon {

}
