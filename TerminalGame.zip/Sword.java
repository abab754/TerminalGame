public class Sword extends Weapon{
    public int useSword(Hero hero){
        return hero.getDamage() + 3;
    }
}
