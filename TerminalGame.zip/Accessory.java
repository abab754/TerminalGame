public class Accessory {
    @Override
    public String toString() {
        return super.toString();
    }
}
